#bin/bash

# 运行方式：
# xx.sh 开始IP 结束IP
# 例如：
# xx.sh  192.168.1.1 192.168.2.1

#first=echo ${var%/*}
echo $1
echo $2
#将起止IP地址转为成数字：
#star=`echo $1 |awk -F. '{print $1*256^3+$2*256^2+$3*256+$4}'`
#end=`echo $2 |awk -F. '{print $1*256^3+$2*256^2+$3*256+$4}'`

#生成两个IP之间所有地址
#seq $star $end |awk  '{i=$0;print int(i/256^3),int(i%256^3/256^2),int(i%256^3%256^2/256),i%256^3%256^2%256}' OFS=.
