#!/bin/bash
# the subnet source file should be one record per line
set -e

## go to script dir

SCRIPTDIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd $SCRIPTDIR

if ! [ -f "dig-google" ]
then
    echo "Please create a file named dig-google"
    echo "Find more Info from README file"
    exit 1
fi
cat dig-google | while read line
do
	first=${line%/*}  # / is the separator
	second=${line##*/}
	final=${first}"_"${second}
	python ../ip_pool.py ${line} | tee ./${final}
	mv ${final} ../google_ip_pool/
done
mv ./dig-google ./dig-google.finished
