#!/bin/bash

set -e

total=`cat ip.find.out | wc -l`
current=`cat tcping.out | wc -l`

progress=$(echo "scale=5; ${current}/${total}*100" |bc)

echo "tcping progress is ${progress}%"

