#!/bin/bash
# "gcc" is the Google Cache server ip addr file
# file format:
#      <START_IP_ADDR><SPACE><END_IP_ADDR>
#    like:
#    1.2.3.0 1.2.3.255
# find instructions in gcc.example file
if ! [ -f "gcc.example" ]
then
    echo "Please make sure gcc.example file is in current folder"
    echo ">>>>>>>>> dont remove example file <<<<<<<<<<<<<<<<<<<"
    exit 1
fi
if ! [ -f "gcc" ]
then
    echo "Please create a file named gcc"
    echo "Find more Info from gcc.example file"
    exit 1
fi
cat gcc | while read line
do
    first=${line% *}  # space is the separator
	second=${line##* }
	#将起止IP地址转为成数字：
	star=`echo $first |awk -F. '{print $1*256^3+$2*256^2+$3*256+$4}'`
	end=`echo $second |awk -F. '{print $1*256^3+$2*256^2+$3*256+$4}'`

	#生成两个IP之间所有地址
	seq $star $end |awk  '{i=$0;print int(i/256^3),int(i%256^3/256^2),int(i%256^3%256^2/256),i%256^3%256^2%256}' OFS=.
done
