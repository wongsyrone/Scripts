#!/bin/bash

# stop if errors occur
set -e

echo "Install python-netaddr, python-numpy package..."
sudo apt-get install python-netaddr python-numpy || \
    sudo yum install python-netaddr python-numpy

# check tcping tool
if ! which tcping > /dev/null
then
    echo "Please install tcping manually to test whether google ip port is open or not"
    echo "Find the Info here: http://www.linuxco.de/tcping/tcping.html"
    exit(1)
fi

# check vim tool
if ! which vim > /dev/null
then
    echo "Please install vim manually using package installer or compile from source"
    echo "Find the Info here: www.vim.org"
    exit(1)
fi

# clean ip.find.out
[ -f "ip.find.out" ] && rm -rf ip.find.out
touch ip.find.out

# we will scan all google's ip with 443 port
for i in $(ls gooole_ip_pool/* | sort -R)
do
    ./find_host_port.py $i | tee -a ip.find.out
done 

# clean tcping.out
[ -f "tcping.out" ] && rm -rf tcping.out
touch tcping.out

echo "We are tcping... this may take very long time"
echo "You can use Ctrl+C to interrupt this "

cat ip.find.out | while read line
do
    tcping -t3 $line 443 | tee -a tcping.out
done

# remove "user timeout" and "closed" line
# add convert to ip.find.out format
sed -i '/user timeout/d' tcping.out
sed -i '/closed/d' tcping.out
sed -i 's/ port 443 open.//g' tcping.out
